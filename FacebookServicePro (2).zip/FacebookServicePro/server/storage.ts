import {
  users, User, InsertUser,
  services, Service, InsertService,
  orders, Order, InsertOrder,
  transactions, Transaction, InsertTransaction,
} from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  
  // Service operations
  getService(id: number): Promise<Service | undefined>;
  getServices(): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, service: Partial<Service>): Promise<Service | undefined>;
  
  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getOrders(): Promise<Order[]>;
  getOrdersByUserId(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Transaction operations
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactions(): Promise<Transaction[]>;
  getTransactionsByUserId(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Utility operations
  addCoinsToUser(userId: number, amount: number): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private services: Map<number, Service>;
  private orders: Map<number, Order>;
  private transactions: Map<number, Transaction>;
  
  private userIdCounter: number;
  private serviceIdCounter: number;
  private orderIdCounter: number;
  private transactionIdCounter: number;

  constructor() {
    this.users = new Map();
    this.services = new Map();
    this.orders = new Map();
    this.transactions = new Map();
    
    this.userIdCounter = 1;
    this.serviceIdCounter = 1;
    this.orderIdCounter = 1;
    this.transactionIdCounter = 1;
    
    // Initialize admin account
    this.initializeAdmin();
    // Initialize default services
    this.initializeServices();
  }

  private async initializeAdmin() {
    const hashedPassword = await bcrypt.hash("19022009", 10);
    const adminUser: InsertUser = {
      username: "Admin",
      email: "levu@gmail.com",
      password: hashedPassword,
      isAdmin: true,
    };
    this.createUser(adminUser);
  }

  private initializeServices() {
    const defaultServices: InsertService[] = [
      {
        name: "Mở checkpoint cơ bản",
        description: "Mở khóa tài khoản Facebook bị checkpoint thông thường",
        price: 150000,
        processingTime: "1-3 ngày",
        isActive: true,
      },
      {
        name: "Mở checkpoint nâng cao",
        description: "Mở khóa tài khoản Facebook bị checkpoint phức tạp, đã nhiều lần vi phạm",
        price: 250000,
        processingTime: "3-5 ngày",
        isActive: true,
      },
      {
        name: "Khôi phục tài khoản bị khóa",
        description: "Khôi phục tài khoản đã bị Facebook khóa vĩnh viễn",
        price: 300000,
        processingTime: "5-7 ngày",
        isActive: true,
      },
      {
        name: "Khôi phục tài khoản bị hack",
        description: "Lấy lại quyền truy cập và kiểm soát tài khoản Facebook đã bị hack",
        price: 350000,
        processingTime: "3-5 ngày",
        isActive: true,
      },
      {
        name: "Gỡ giới hạn tính năng",
        description: "Gỡ bỏ các giới hạn về tính năng trên tài khoản Facebook",
        price: 200000,
        processingTime: "3-5 ngày",
        isActive: true,
      },
    ];

    defaultServices.forEach(service => this.createService(service));
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.email.toLowerCase() === email.toLowerCase()) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = {
      ...userData,
      id,
      coins: 0,
      createdAt: now,
    };
    this.users.set(id, user);
    return user;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async createService(serviceData: InsertService): Promise<Service> {
    const id = this.serviceIdCounter++;
    const service: Service = {
      ...serviceData,
      id,
    };
    this.services.set(id, service);
    return service;
  }

  async updateService(id: number, serviceData: Partial<Service>): Promise<Service | undefined> {
    const existingService = this.services.get(id);
    if (!existingService) return undefined;

    const updatedService: Service = {
      ...existingService,
      ...serviceData,
    };
    
    this.services.set(id, updatedService);
    return updatedService;
  }

  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrdersByUserId(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.userId === userId);
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const now = new Date();
    const order: Order = {
      ...orderData,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const existingOrder = this.orders.get(id);
    if (!existingOrder) return undefined;

    const now = new Date();
    const updatedOrder: Order = {
      ...existingOrder,
      status,
      updatedAt: now,
    };
    
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Transaction operations
  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async getTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values());
  }

  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(transaction => transaction.userId === userId);
  }

  async createTransaction(transactionData: InsertTransaction): Promise<Transaction> {
    const id = this.transactionIdCounter++;
    const now = new Date();
    const transaction: Transaction = {
      ...transactionData,
      id,
      createdAt: now,
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // Utility operations
  async addCoinsToUser(userId: number, amount: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      coins: user.coins + amount,
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
}

export const storage = new MemStorage();
