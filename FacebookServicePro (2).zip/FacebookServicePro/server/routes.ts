import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  loginSchema, 
  registerSchema, 
  createOrderSchema, 
  addCoinsSchema,
  insertUserSchema,
  insertOrderSchema,
  insertTransactionSchema
} from "@shared/schema";
import bcrypt from "bcryptjs";
import session from "express-session";
import MemoryStore from "memorystore";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const SessionStore = MemoryStore(session);

  // Setup session
  app.use(
    session({
      secret: "fb-services-secret-key",
      resave: false,
      saveUninitialized: false,
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.session.userId) {
      return next();
    }
    return res.status(401).json({ message: "Vui lòng đăng nhập để tiếp tục" });
  };

  const isAdmin = async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Vui lòng đăng nhập để tiếp tục" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Bạn không có quyền truy cập vào tài nguyên này" });
    }

    return next();
  };

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if email already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email đã được sử dụng" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      
      // Create user
      const userData = insertUserSchema.parse({
        username: validatedData.username,
        email: validatedData.email,
        password: hashedPassword,
        isAdmin: false,
      });

      const newUser = await storage.createUser(userData);
      
      // Set session
      req.session.userId = newUser.id;
      req.session.isAdmin = newUser.isAdmin;
      
      // Return user without password
      const { password, ...userWithoutPassword } = newUser;
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(400).json({ message: "Đăng ký không thành công", error });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      
      // Find user by email
      const user = await storage.getUserByEmail(validatedData.email);
      if (!user) {
        return res.status(400).json({ message: "Email hoặc mật khẩu không chính xác" });
      }

      // Verify password
      const isPasswordValid = await bcrypt.compare(validatedData.password, user.password);
      if (!isPasswordValid) {
        return res.status(400).json({ message: "Email hoặc mật khẩu không chính xác" });
      }

      // Set session
      req.session.userId = user.id;
      req.session.isAdmin = user.isAdmin;
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      return res.status(400).json({ message: "Đăng nhập không thành công", error });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Đăng xuất không thành công" });
      }
      return res.status(200).json({ message: "Đăng xuất thành công" });
    });
  });

  app.get("/api/auth/me", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "Người dùng không tồn tại" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Get user error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy thông tin người dùng" });
    }
  });

  // Service routes
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getServices();
      return res.status(200).json(services);
    } catch (error) {
      console.error("Get services error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy danh sách dịch vụ" });
    }
  });

  app.get("/api/services/:id", async (req, res) => {
    try {
      const serviceId = parseInt(req.params.id);
      const service = await storage.getService(serviceId);
      
      if (!service) {
        return res.status(404).json({ message: "Dịch vụ không tồn tại" });
      }
      
      return res.status(200).json(service);
    } catch (error) {
      console.error("Get service error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy thông tin dịch vụ" });
    }
  });

  // Order routes
  app.post("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const validatedData = createOrderSchema.parse(req.body);
      const userId = req.session.userId!;
      
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Người dùng không tồn tại" });
      }
      
      // Get service
      const service = await storage.getService(validatedData.serviceId);
      if (!service) {
        return res.status(404).json({ message: "Dịch vụ không tồn tại" });
      }
      
      // Check user coins
      if (user.coins < service.price) {
        return res.status(400).json({ message: "Số dư không đủ để thực hiện giao dịch này" });
      }
      
      // Create order
      const orderData = insertOrderSchema.parse({
        userId,
        serviceId: validatedData.serviceId,
        fbEmail: validatedData.fbEmail,
        fbUrl: validatedData.fbUrl,
        description: validatedData.description,
        price: service.price,
        status: "pending", // initial status
      });
      
      const newOrder = await storage.createOrder(orderData);
      
      // Create payment transaction
      const transactionData = insertTransactionSchema.parse({
        userId,
        amount: -service.price, // negative for payment
        description: `Thanh toán đơn hàng #${newOrder.id} - ${service.name}`,
        type: "payment",
      });
      
      await storage.createTransaction(transactionData);
      
      // Subtract coins from user
      await storage.addCoinsToUser(userId, -service.price);
      
      return res.status(201).json(newOrder);
    } catch (error) {
      console.error("Create order error:", error);
      return res.status(400).json({ message: "Tạo đơn hàng không thành công", error });
    }
  });

  app.get("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Người dùng không tồn tại" });
      }
      
      let orders;
      if (user.isAdmin) {
        // Admin can see all orders
        orders = await storage.getOrders();
      } else {
        // Regular users can only see their own orders
        orders = await storage.getOrdersByUserId(userId);
      }
      
      return res.status(200).json(orders);
    } catch (error) {
      console.error("Get orders error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy danh sách đơn hàng" });
    }
  });

  app.get("/api/orders/:id", isAuthenticated, async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Đơn hàng không tồn tại" });
      }
      
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      // Check if user is authorized to see this order
      if (!user?.isAdmin && order.userId !== userId) {
        return res.status(403).json({ message: "Bạn không có quyền xem đơn hàng này" });
      }
      
      return res.status(200).json(order);
    } catch (error) {
      console.error("Get order error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy thông tin đơn hàng" });
    }
  });

  app.patch("/api/orders/:id/status", isAdmin, async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["pending", "processing", "completed", "failed"].includes(status)) {
        return res.status(400).json({ message: "Trạng thái không hợp lệ" });
      }
      
      const updatedOrder = await storage.updateOrderStatus(orderId, status);
      
      if (!updatedOrder) {
        return res.status(404).json({ message: "Đơn hàng không tồn tại" });
      }
      
      return res.status(200).json(updatedOrder);
    } catch (error) {
      console.error("Update order status error:", error);
      return res.status(500).json({ message: "Lỗi khi cập nhật trạng thái đơn hàng" });
    }
  });

  // User routes (admin only)
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getUsers();
      
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      return res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      console.error("Get users error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy danh sách người dùng" });
    }
  });

  // Coin management routes
  app.post("/api/users/:id/add-coins", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const validatedData = addCoinsSchema.parse({
        ...req.body,
        userId,
      });
      
      // Verify user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Người dùng không tồn tại" });
      }
      
      // Add coins to user
      const updatedUser = await storage.addCoinsToUser(userId, validatedData.amount);
      
      // Create deposit transaction
      const transactionData = insertTransactionSchema.parse({
        userId,
        amount: validatedData.amount,
        description: validatedData.description || "Nạp coin bởi admin",
        type: "deposit",
      });
      
      await storage.createTransaction(transactionData);
      
      // Return updated user without password
      if (updatedUser) {
        const { password, ...userWithoutPassword } = updatedUser;
        return res.status(200).json(userWithoutPassword);
      } else {
        return res.status(500).json({ message: "Lỗi khi nạp coin cho người dùng" });
      }
    } catch (error) {
      console.error("Add coins error:", error);
      return res.status(400).json({ message: "Nạp coin không thành công", error });
    }
  });

  // Transaction routes
  app.get("/api/transactions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Người dùng không tồn tại" });
      }
      
      let transactions;
      if (user.isAdmin) {
        // Admin can see all transactions
        transactions = await storage.getTransactions();
      } else {
        // Regular users can only see their own transactions
        transactions = await storage.getTransactionsByUserId(userId);
      }
      
      return res.status(200).json(transactions);
    } catch (error) {
      console.error("Get transactions error:", error);
      return res.status(500).json({ message: "Lỗi khi lấy lịch sử giao dịch" });
    }
  });

  return httpServer;
}
