#!/bin/bash
export NODE_ENV=development
export PORT=5001
~/.bun/bin/bun --watch server/index.ts