import { useState, useEffect } from "react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AddCoinsForm } from "./AddCoinsForm";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

export default function UsersTable() {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isAddCoinsDialogOpen, setIsAddCoinsDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchUsers() {
      try {
        setIsLoading(true);
        const res = await apiRequest("GET", "/api/users");
        const usersData = await res.json();
        setUsers(usersData);
      } catch (error) {
        console.error("Failed to fetch users:", error);
        toast({
          title: "Lỗi khi tải dữ liệu",
          description: "Không thể tải danh sách người dùng. Vui lòng thử lại sau.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }

    fetchUsers();
  }, [toast]);

  const handleAddCoins = (user: User) => {
    setSelectedUser(user);
    setIsAddCoinsDialogOpen(true);
  };

  const handleCoinsAdded = (updatedUser: User) => {
    setUsers(users.map(user => user.id === updatedUser.id ? updatedUser : user));
    setIsAddCoinsDialogOpen(false);
    
    toast({
      title: "Nạp coin thành công",
      description: `Đã nạp coins vào tài khoản của ${updatedUser.username}.`,
    });
  };

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN");
  };

  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof User,
    },
    {
      header: "Tên",
      accessorKey: "username" as keyof User,
    },
    {
      header: "Email",
      accessorKey: "email" as keyof User,
    },
    {
      header: "Coins",
      accessorKey: "coins" as keyof User,
      cell: (row: User) => row.coins.toLocaleString(),
    },
    {
      header: "Vai trò",
      accessorKey: "isAdmin" as keyof User,
      cell: (row: User) => (
        row.isAdmin ? 
          <Badge className="bg-primary-100 text-primary-800 hover:bg-primary-100">Admin</Badge> : 
          <Badge variant="outline">Người dùng</Badge>
      ),
    },
    {
      header: "Ngày đăng ký",
      accessorKey: "createdAt" as keyof User,
      cell: (row: User) => formatDate(row.createdAt),
    },
    {
      header: "Thao tác",
      accessorKey: "actions",
      cell: (row: User) => (
        <div className="flex space-x-2">
          <Button 
            onClick={(e) => {
              e.stopPropagation();
              handleAddCoins(row);
            }} 
            variant="outline" 
            size="sm"
          >
            Thêm coin
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <DataTable
        data={users}
        columns={columns}
        searchKey="username"
        pageSize={10}
      />
      
      {selectedUser && (
        <Dialog 
          open={isAddCoinsDialogOpen} 
          onOpenChange={setIsAddCoinsDialogOpen}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nạp coin cho người dùng</DialogTitle>
            </DialogHeader>
            <AddCoinsForm 
              user={selectedUser} 
              onCoinsAdded={handleCoinsAdded} 
              onCancel={() => setIsAddCoinsDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
