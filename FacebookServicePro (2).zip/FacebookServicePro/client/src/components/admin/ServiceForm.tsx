import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { apiRequest } from "@/lib/queryClient";
import { Service } from "@shared/schema";

interface ServiceFormProps {
  service: Service | null;
  onSuccess: (service: Service) => void;
  onCancel: () => void;
}

// Form schema
const formSchema = z.object({
  name: z.string().min(1, "Tên dịch vụ không được để trống"),
  description: z.string().min(1, "Mô tả không được để trống"),
  price: z.coerce.number().positive("Giá phải lớn hơn 0"),
  processingTime: z.string().min(1, "Thời gian xử lý không được để trống"),
  isActive: z.boolean().default(true),
});

type FormValues = z.infer<typeof formSchema>;

export default function ServiceForm({ service, onSuccess, onCancel }: ServiceFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isEditing = !!service;

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: service?.name || "",
      description: service?.description || "",
      price: service?.price || 0,
      processingTime: service?.processingTime || "",
      isActive: service?.isActive ?? true,
    },
  });

  const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true);
    
    try {
      let response;
      
      if (isEditing) {
        response = await apiRequest(
          "PATCH",
          `/api/services/${service.id}`,
          values
        );
      } else {
        response = await apiRequest(
          "POST",
          "/api/services",
          values
        );
      }
      
      const serviceData = await response.json();
      onSuccess(serviceData);
    } catch (error) {
      console.error("Failed to save service:", error);
      form.setError("root", {
        message: isEditing 
          ? "Có lỗi xảy ra khi cập nhật dịch vụ. Vui lòng thử lại." 
          : "Có lỗi xảy ra khi tạo dịch vụ mới. Vui lòng thử lại.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tên dịch vụ</FormLabel>
              <FormControl>
                <Input placeholder="Nhập tên dịch vụ" {...field} />
              </FormControl>
              <FormDescription>
                Tên dịch vụ sẽ hiển thị cho người dùng
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Mô tả</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Mô tả chi tiết về dịch vụ" 
                  rows={3}
                  {...field} 
                />
              </FormControl>
              <FormDescription>
                Giới thiệu ngắn gọn về dịch vụ và lợi ích
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="price"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Giá (Coins)</FormLabel>
                <FormControl>
                  <Input type="number" min="1" {...field} />
                </FormControl>
                <FormDescription>
                  Giá dịch vụ tính bằng coins
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="processingTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Thời gian xử lý</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Ví dụ: 1-3 ngày" 
                    {...field} 
                  />
                </FormControl>
                <FormDescription>
                  Thời gian dự kiến để hoàn thành dịch vụ
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Trạng thái dịch vụ</FormLabel>
                <FormDescription>
                  Dịch vụ có sẵn sàng cho người dùng đặt hàng không
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        {form.formState.errors.root && (
          <div className="text-sm font-medium text-destructive">
            {form.formState.errors.root.message}
          </div>
        )}
        
        <div className="flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Hủy
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Đang xử lý..." : isEditing ? "Cập nhật" : "Tạo dịch vụ"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
