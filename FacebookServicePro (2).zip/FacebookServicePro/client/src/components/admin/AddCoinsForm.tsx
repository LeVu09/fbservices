import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { User } from "@shared/schema";

interface AddCoinsFormProps {
  user: User;
  onCoinsAdded: (updatedUser: User) => void;
  onCancel: () => void;
}

// Form schema
const formSchema = z.object({
  amount: z.coerce.number().positive("Số coin phải lớn hơn 0"),
  description: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function AddCoinsForm({ user, onCoinsAdded, onCancel }: AddCoinsFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: 0,
      description: "",
    },
  });

  const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true);
    
    try {
      const response = await apiRequest(
        "POST",
        `/api/users/${user.id}/add-coins`,
        {
          amount: values.amount,
          description: values.description || "Nạp coin bởi admin",
        }
      );
      
      const updatedUser = await response.json();
      onCoinsAdded(updatedUser);
    } catch (error) {
      console.error("Failed to add coins:", error);
      form.setError("root", {
        message: "Có lỗi xảy ra khi nạp coin. Vui lòng thử lại.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="mb-4">
          <div className="flex items-center">
            <span className="text-sm font-medium text-gray-500">Người dùng:</span>
            <span className="ml-2 font-medium">{user.username}</span>
          </div>
          <div className="flex items-center mt-1">
            <span className="text-sm font-medium text-gray-500">Email:</span>
            <span className="ml-2">{user.email}</span>
          </div>
          <div className="flex items-center mt-1">
            <span className="text-sm font-medium text-gray-500">Số dư hiện tại:</span>
            <span className="ml-2 font-medium">{user.coins.toLocaleString()} coins</span>
          </div>
        </div>
        
        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Số lượng coin</FormLabel>
              <FormControl>
                <Input type="number" min="1" {...field} />
              </FormControl>
              <FormDescription>
                Nhập số lượng coin cần nạp vào tài khoản người dùng.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ghi chú</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Ghi chú giao dịch (không bắt buộc)" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {form.formState.errors.root && (
          <div className="text-sm font-medium text-destructive">
            {form.formState.errors.root.message}
          </div>
        )}
        
        <div className="flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSubmitting}
          >
            Hủy
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Đang xử lý..." : "Nạp coin"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
