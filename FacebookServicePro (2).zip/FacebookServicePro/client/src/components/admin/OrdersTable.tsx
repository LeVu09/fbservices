import { useState, useEffect } from "react";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Order, Service, User } from "@shared/schema";

export default function OrdersTable() {
  const [isLoading, setIsLoading] = useState(true);
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [newStatus, setNewStatus] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        
        const [ordersRes, usersRes, servicesRes] = await Promise.all([
          apiRequest("GET", "/api/orders"),
          apiRequest("GET", "/api/users"),
          apiRequest("GET", "/api/services"),
        ]);
        
        const ordersData = await ordersRes.json();
        const usersData = await usersRes.json();
        const servicesData = await servicesRes.json();
        
        setOrders(ordersData);
        setUsers(usersData);
        setServices(servicesData);
      } catch (error) {
        console.error("Failed to fetch orders:", error);
        toast({
          title: "Lỗi khi tải dữ liệu",
          description: "Không thể tải danh sách đơn hàng. Vui lòng thử lại sau.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [toast]);

  const getUserName = (userId: number) => {
    const user = users.find((u) => u.id === userId);
    return user ? user.username : `User #${userId}`;
  };

  const getUserEmail = (userId: number) => {
    const user = users.find((u) => u.id === userId);
    return user ? user.email : "";
  };

  const getServiceName = (serviceId: number) => {
    const service = services.find((s) => s.id === serviceId);
    return service ? service.name : `Service #${serviceId}`;
  };

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN") + " " + date.toLocaleTimeString("vi-VN");
  };

  const handleUpdateStatus = async () => {
    if (!selectedOrder || !newStatus) return;
    
    try {
      const res = await apiRequest("PATCH", `/api/orders/${selectedOrder.id}/status`, {
        status: newStatus,
      });
      
      const updatedOrder = await res.json();
      
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === updatedOrder.id ? updatedOrder : order
        )
      );
      
      toast({
        title: "Cập nhật thành công",
        description: `Đơn hàng #${selectedOrder.id} đã được cập nhật trạng thái.`,
      });
      
      // Invalidate orders query to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      
      setIsUpdateDialogOpen(false);
    } catch (error) {
      console.error("Failed to update order status:", error);
      toast({
        title: "Cập nhật thất bại",
        description: "Không thể cập nhật trạng thái đơn hàng. Vui lòng thử lại.",
        variant: "destructive",
      });
    }
  };

  const handleRowClick = (order: Order) => {
    setSelectedOrder(order);
    setNewStatus(order.status);
    setIsUpdateDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    if (status === "pending") {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Đang chờ</Badge>;
    } else if (status === "processing") {
      return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Đang xử lý</Badge>;
    } else if (status === "completed") {
      return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Hoàn thành</Badge>;
    } else if (status === "failed") {
      return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Thất bại</Badge>;
    }
    return <Badge variant="outline">{status}</Badge>;
  };

  const columns = [
    {
      header: "Mã đơn",
      accessorKey: "id" as keyof Order,
      cell: (row: Order) => `#${row.id}`,
    },
    {
      header: "Dịch vụ",
      accessorKey: "serviceId" as keyof Order,
      cell: (row: Order) => getServiceName(row.serviceId),
    },
    {
      header: "Khách hàng",
      accessorKey: "userId" as keyof Order,
      cell: (row: Order) => (
        <div>
          <div className="font-medium">{getUserName(row.userId)}</div>
          <div className="text-sm text-gray-500">{getUserEmail(row.userId)}</div>
        </div>
      ),
    },
    {
      header: "Ngày tạo",
      accessorKey: "createdAt" as keyof Order,
      cell: (row: Order) => formatDate(row.createdAt),
    },
    {
      header: "Giá",
      accessorKey: "price" as keyof Order,
      cell: (row: Order) => `${row.price.toLocaleString()} ₫`,
    },
    {
      header: "Trạng thái",
      accessorKey: "status" as keyof Order,
      cell: (row: Order) => getStatusBadge(row.status),
    },
    {
      header: "Thao tác",
      accessorKey: "actions",
      cell: (row: Order) => (
        <Button onClick={(e) => {
          e.stopPropagation();
          handleRowClick(row);
        }} variant="outline" size="sm">
          Cập nhật
        </Button>
      ),
    },
  ];

  return (
    <div>
      <DataTable
        data={orders}
        columns={columns}
        searchKey="id"
        pageSize={10}
        onRowClick={handleRowClick}
      />

      {selectedOrder && (
        <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cập nhật trạng thái đơn hàng</DialogTitle>
              <DialogDescription>
                Đơn hàng #{selectedOrder.id} - {getServiceName(selectedOrder.serviceId)}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Khách hàng:</div>
                <div className="col-span-3">
                  {getUserName(selectedOrder.userId)} ({getUserEmail(selectedOrder.userId)})
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Email Facebook:</div>
                <div className="col-span-3">{selectedOrder.fbEmail}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">URL Facebook:</div>
                <div className="col-span-3">{selectedOrder.fbUrl}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Mô tả:</div>
                <div className="col-span-3">{selectedOrder.description}</div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Trạng thái hiện tại:</div>
                <div className="col-span-3">{getStatusBadge(selectedOrder.status)}</div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-sm font-medium">Trạng thái mới:</div>
                <div className="col-span-3">
                  <Select value={newStatus} onValueChange={setNewStatus}>
                    <SelectTrigger>
                      <SelectValue placeholder="Chọn trạng thái mới" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Đang chờ</SelectItem>
                      <SelectItem value="processing">Đang xử lý</SelectItem>
                      <SelectItem value="completed">Hoàn thành</SelectItem>
                      <SelectItem value="failed">Thất bại</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsUpdateDialogOpen(false)}>
                Hủy
              </Button>
              <Button onClick={handleUpdateStatus}>Cập nhật</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
