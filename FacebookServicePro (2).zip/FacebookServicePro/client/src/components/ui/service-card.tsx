import { ReactNode } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ServiceCardProps {
  title: string;
  description: string;
  price: number;
  features?: string[];
  icon?: ReactNode;
  onOrderClick?: () => void;
  imageSrc?: string;
  processingTime?: string;
  badge?: string;
  id?: number;
}

export function ServiceCard({
  title,
  description,
  price,
  features,
  icon,
  onOrderClick,
  imageSrc,
  processingTime,
  badge,
  id,
}: ServiceCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-xl h-full flex flex-col">
      {imageSrc && (
        <div className="h-48 bg-gray-200 relative">
          <img
            src={imageSrc}
            alt={title}
            className="w-full h-full object-cover"
          />
          {badge && (
            <div className="absolute bottom-0 left-0 p-4">
              <span className="bg-primary-600 text-white px-2 py-1 rounded-md text-xs font-medium">
                {badge}
              </span>
            </div>
          )}
        </div>
      )}
      <CardContent className="p-6 flex-1">
        {icon && (
          <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
            {icon}
          </div>
        )}
        <h3 className="text-lg font-bold text-gray-900">
          <a href={`/service/${id}`} className="hover:text-primary-600 transition-colors">
            {title}
          </a>
        </h3>
        <p className="mt-2 text-gray-600">{description}</p>
        
        <div className="mt-4 bg-blue-50 rounded-md p-4">
          <p className="text-center text-primary-600 font-bold text-2xl">
            {price.toLocaleString()} ₫
          </p>
          {processingTime && (
            <p className="text-center text-gray-500 text-sm">
              Thời gian xử lý: {processingTime}
            </p>
          )}
        </div>
        
        {features && features.length > 0 && (
          <div className="mt-6">
            <ul className="space-y-3">
              {features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <svg
                    className="h-5 w-5 text-green-500 mt-1 mr-2"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <span className="text-gray-600">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-6 pt-0 flex flex-col sm:flex-row gap-2">
        <Button
          variant="outline"
          className="w-full sm:w-1/2"
          onClick={() => window.location.href = `/service/${id}`}
        >
          Chi tiết
        </Button>
        <Button
          className="w-full sm:w-1/2"
          onClick={onOrderClick}
        >
          Đặt dịch vụ
        </Button>
      </CardFooter>
    </Card>
  );
}
