import { useState } from "react";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

type Testimonial = {
  id: number;
  name: string;
  role: string;
  content: string;
  avatarUrl: string;
};

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Nguyễn Văn A",
    role: "Kinh doanh online",
    content: "Tài khoản Facebook của tôi bị checkpoint và không thể truy cập. Nhờ dịch vụ mở checkpoint của họ, tôi đã lấy lại được tài khoản trong vòng 2 ngày. Rất nhanh chóng và chuyên nghiệp!",
    avatarUrl: "https://randomuser.me/api/portraits/men/1.jpg",
  },
  {
    id: 2,
    name: "Trần Thị B",
    role: "Nhân viên văn phòng",
    content: "Tôi đã bị hack tài khoản Facebook và mất toàn bộ quyền truy cập. Đội ngũ hỗ trợ rất tận tình và giúp tôi lấy lại được tài khoản chỉ sau 3 ngày. Tuyệt vời!",
    avatarUrl: "https://randomuser.me/api/portraits/women/2.jpg",
  },
  {
    id: 3,
    name: "Lê Văn C",
    role: "Chủ shop online",
    content: "Shop online của tôi hoàn toàn phụ thuộc vào Facebook, và khi bị khóa tài khoản, tôi thực sự rất lo lắng. Dịch vụ phục hồi tài khoản này đã cứu cả việc kinh doanh của tôi!",
    avatarUrl: "https://randomuser.me/api/portraits/men/3.jpg",
  },
  {
    id: 4,
    name: "Phạm Thị D",
    role: "Content creator",
    content: "Tôi làm việc với nhiều tài khoản Facebook và một trong số đó bị giới hạn tính năng. Dịch vụ gỡ giới hạn của họ rất hiệu quả và giúp tôi tiếp tục công việc một cách suôn sẻ.",
    avatarUrl: "https://randomuser.me/api/portraits/women/4.jpg",
  },
  {
    id: 5,
    name: "Vũ Minh E",
    role: "Marketer",
    content: "Đã thử nhiều dịch vụ khác nhau nhưng không ai có thể giúp mở khóa tài khoản Facebook bị checkpoint nâng cao của tôi. Rất may là đã tìm được dịch vụ này và họ đã giải quyết vấn đề một cách nhanh chóng.",
    avatarUrl: "https://randomuser.me/api/portraits/men/5.jpg",
  },
];

export default function ServiceTestimonials() {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-2xl sm:text-3xl font-heading font-bold text-gray-900">
            Khách hàng nói gì về chúng tôi
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-base text-gray-500">
            Hàng ngàn khách hàng đã tin tưởng dịch vụ của chúng tôi và lấy lại quyền truy cập vào tài khoản Facebook của họ.
          </p>
        </div>

        <div className="mt-10">
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent>
              {testimonials.map((testimonial) => (
                <CarouselItem key={testimonial.id} className="md:basis-1/2 lg:basis-1/3 pl-4">
                  <Card className="h-full">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-4">
                        <img
                          src={testimonial.avatarUrl}
                          alt={testimonial.name}
                          className="h-12 w-12 rounded-full object-cover mr-4"
                        />
                        <div>
                          <p className="font-semibold text-gray-900">{testimonial.name}</p>
                          <p className="text-sm text-gray-500">{testimonial.role}</p>
                        </div>
                      </div>
                      <div className="mb-4">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span key={star} className="text-yellow-400">★</span>
                        ))}
                      </div>
                      <p className="text-gray-600">{testimonial.content}</p>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="flex justify-center mt-6 gap-2">
              <CarouselPrevious />
              <CarouselNext />
            </div>
          </Carousel>
        </div>
      </div>
    </section>
  );
}