import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentUser } from "@/lib/auth";
import { Service, createOrderSchema, User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";

interface CreateOrderFormProps {
  preselectedServiceId?: string;
}

export default function CreateOrderForm({ preselectedServiceId }: CreateOrderFormProps) {
  const [services, setServices] = useState<Service[]>([]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const formSchema = createOrderSchema.extend({
    agreeTerms: z.boolean().refine(val => val === true, {
      message: "Bạn phải đồng ý với điều khoản dịch vụ để tiếp tục.",
    }),
  });

  type FormValues = z.infer<typeof formSchema>;

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      serviceId: parseInt(preselectedServiceId || "0") || undefined,
      fbEmail: "",
      fbUrl: "",
      description: "",
      agreeTerms: false,
    },
  });

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        const [servicesRes, userData] = await Promise.all([
          apiRequest("GET", "/api/services"),
          getCurrentUser(),
        ]);
        
        const servicesData = await servicesRes.json();
        
        setServices(servicesData);
        setUser(userData);
        
        // Set selected service if preselected
        if (preselectedServiceId) {
          const selectedServiceId = parseInt(preselectedServiceId);
          const service = servicesData.find(s => s.id === selectedServiceId);
          if (service) {
            setSelectedService(service);
            form.setValue("serviceId", selectedServiceId);
          }
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
        toast({
          title: "Lỗi khi tải dữ liệu",
          description: "Không thể tải dịch vụ hoặc thông tin người dùng. Vui lòng thử lại sau.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [toast, preselectedServiceId, form]);

  // Watch for service ID changes
  useEffect(() => {
    const serviceId = form.watch("serviceId");
    if (serviceId) {
      const service = services.find(s => s.id === serviceId);
      setSelectedService(service || null);
    } else {
      setSelectedService(null);
    }
  }, [form.watch("serviceId"), services]);

  const onSubmit = async (values: FormValues) => {
    if (!selectedService) {
      toast({
        title: "Vui lòng chọn dịch vụ",
        description: "Bạn cần chọn một dịch vụ để tiếp tục.",
        variant: "destructive",
      });
      return;
    }

    if (!user) {
      toast({
        title: "Bạn cần đăng nhập",
        description: "Vui lòng đăng nhập để tạo đơn hàng.",
        variant: "destructive",
      });
      navigate("/login");
      return;
    }

    if (user.coins < selectedService.price) {
      toast({
        title: "Số dư không đủ",
        description: "Số dư coin của bạn không đủ để sử dụng dịch vụ này. Vui lòng nạp thêm coin.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await apiRequest("POST", "/api/orders", {
        serviceId: values.serviceId,
        fbEmail: values.fbEmail,
        fbUrl: values.fbUrl,
        description: values.description,
      });

      const order = await response.json();

      toast({
        title: "Tạo đơn hàng thành công",
        description: `Đơn hàng #${order.id} đã được tạo thành công và đang chờ xử lý.`,
      });

      navigate("/user/orders");
    } catch (error) {
      console.error("Failed to create order:", error);
      toast({
        title: "Tạo đơn hàng thất bại",
        description: "Có lỗi xảy ra khi tạo đơn hàng. Vui lòng thử lại sau.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
      </div>
    );
  }

  const remainingBalance = user && selectedService ? user.coins - selectedService.price : user?.coins || 0;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h2 className="text-lg font-medium leading-6 text-gray-900">Tạo đơn hàng mới</h2>
          <p className="mt-1 text-sm text-gray-500">Vui lòng điền đầy đủ thông tin để tạo đơn hàng.</p>
        </div>
        
        <div className="border-t border-gray-200">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="divide-y divide-gray-200">
              {/* Service Selection */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">Chọn dịch vụ</h3>
                <div className="mt-5">
                  <FormField
                    control={form.control}
                    name="serviceId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loại dịch vụ</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Chọn loại dịch vụ" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {services.map((service) => (
                              <SelectItem key={service.id} value={service.id.toString()}>
                                {service.name} ({service.price.toLocaleString()} coins)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Account Information */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">Thông tin tài khoản</h3>
                <div className="mt-5 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                  <FormField
                    control={form.control}
                    name="fbEmail"
                    render={({ field }) => (
                      <FormItem className="sm:col-span-6">
                        <FormLabel>Email đăng nhập Facebook</FormLabel>
                        <FormControl>
                          <Input placeholder="Email/SĐT đăng nhập Facebook" {...field} />
                        </FormControl>
                        <FormDescription>
                          Email hoặc số điện thoại bạn sử dụng để đăng nhập vào tài khoản Facebook.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="fbUrl"
                    render={({ field }) => (
                      <FormItem className="sm:col-span-6">
                        <FormLabel>Link Facebook hoặc ID</FormLabel>
                        <FormControl>
                          <Input placeholder="https://facebook.com/username hoặc ID" {...field} />
                        </FormControl>
                        <FormDescription>
                          Link đến trang cá nhân Facebook hoặc ID tài khoản của bạn.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Issue Description */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">Mô tả vấn đề</h3>
                <div className="mt-5">
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Chi tiết vấn đề</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Mô tả chi tiết vấn đề bạn đang gặp phải với tài khoản Facebook"
                            rows={4}
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Cung cấp càng nhiều thông tin càng tốt để chúng tôi có thể hỗ trợ bạn hiệu quả.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Confirmation */}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">Xác nhận đơn hàng</h3>
                <div className="mt-5">
                  <FormField
                    control={form.control}
                    name="agreeTerms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 bg-gray-50">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            Tôi xác nhận thông tin là chính xác và đồng ý với 
                            <Button variant="link" className="px-1 py-0 h-auto">Điều khoản dịch vụ</Button> 
                            và 
                            <Button variant="link" className="px-1 py-0 h-auto">Chính sách bảo mật</Button>.
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />

                  <div className="mt-5 bg-gray-50 p-4 rounded-md">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tổng thanh toán:</span>
                      <span className="text-gray-900 font-bold">
                        {selectedService ? selectedService.price.toLocaleString() : 0} coins
                      </span>
                    </div>
                    <div className="flex justify-between mt-2">
                      <span className="text-gray-600">Số dư hiện tại:</span>
                      <span className="text-gray-900 font-bold">
                        {user ? user.coins.toLocaleString() : 0} coins
                      </span>
                    </div>
                    <div className="flex justify-between mt-2">
                      <span className="text-gray-600">Số dư còn lại:</span>
                      <span className={`font-bold ${remainingBalance < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                        {remainingBalance.toLocaleString()} coins
                      </span>
                    </div>
                    
                    {remainingBalance < 0 && (
                      <div className="mt-2 text-sm text-red-600">
                        Số dư không đủ. Vui lòng nạp thêm coin để tiếp tục.
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
                <Button
                  type="button"
                  variant="outline"
                  className="mr-2"
                  onClick={() => navigate("/user/dashboard")}
                >
                  Hủy
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting || !selectedService || remainingBalance < 0}
                >
                  {isSubmitting ? "Đang xử lý..." : "Tạo đơn hàng"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
