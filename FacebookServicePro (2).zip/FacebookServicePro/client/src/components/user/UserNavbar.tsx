import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  User,
  Package,
  CreditCard,
  ShoppingBag,
  Home,
  LogOut,
} from "lucide-react";
import { User as UserType } from "@shared/schema";
import { getCurrentUser, logout } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export default function UserNavbar() {
  const [location] = useLocation();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [user, setUser] = useState<UserType | null>(null);

  useEffect(() => {
    async function fetchUser() {
      try {
        const userData = await getCurrentUser();
        setUser(userData);
      } catch (error) {
        console.error("Failed to fetch user:", error);
      }
    }

    fetchUser();
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
      toast({
        title: "Đăng xuất thành công",
        description: "Bạn đã đăng xuất khỏi hệ thống",
      });
    } catch (error) {
      console.error("Logout failed:", error);
      toast({
        title: "Đăng xuất thất bại",
        description: "Có lỗi xảy ra khi đăng xuất",
        variant: "destructive",
      });
    }
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <div className="space-y-6">
      {user && (
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <div className="flex items-center space-x-4">
            <div className="h-12 w-12 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center">
              <User className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900">{user.username}</h3>
              <p className="text-sm text-gray-500">{user.email}</p>
            </div>
          </div>
          <div className="mt-4 p-3 bg-gray-50 rounded-md flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CreditCard className="h-5 w-5 text-yellow-500" />
              <span className="font-medium">{user.coins.toLocaleString()}</span>
              <span className="text-sm text-gray-500">coins</span>
            </div>
            <Button size="sm" onClick={() => navigate("/user/wallet")}>
              Nạp thêm
            </Button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-4 border-b">
          <h3 className="font-medium">Điều hướng</h3>
        </div>
        <nav className="p-4 space-y-2">
          <Link href="/">
            <a
              className={`flex items-center space-x-2 p-2 rounded-md ${
                isActive("/")
                  ? "bg-primary-50 text-primary-600"
                  : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              }`}
            >
              <Home className="h-5 w-5" />
              <span>Trang chủ</span>
            </a>
          </Link>
          <Link href="/user/dashboard">
            <a
              className={`flex items-center space-x-2 p-2 rounded-md ${
                isActive("/user/dashboard")
                  ? "bg-primary-50 text-primary-600"
                  : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              }`}
            >
              <User className="h-5 w-5" />
              <span>Tài khoản</span>
            </a>
          </Link>
          <Link href="/user/orders">
            <a
              className={`flex items-center space-x-2 p-2 rounded-md ${
                isActive("/user/orders")
                  ? "bg-primary-50 text-primary-600"
                  : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              }`}
            >
              <Package className="h-5 w-5" />
              <span>Đơn hàng của tôi</span>
            </a>
          </Link>
          <Link href="/user/wallet">
            <a
              className={`flex items-center space-x-2 p-2 rounded-md ${
                isActive("/user/wallet")
                  ? "bg-primary-50 text-primary-600"
                  : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              }`}
            >
              <CreditCard className="h-5 w-5" />
              <span>Ví của tôi</span>
            </a>
          </Link>
          <Link href="/user/create-order">
            <a
              className={`flex items-center space-x-2 p-2 rounded-md ${
                isActive("/user/create-order")
                  ? "bg-primary-50 text-primary-600"
                  : "text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              }`}
            >
              <ShoppingBag className="h-5 w-5" />
              <span>Tạo đơn hàng</span>
            </a>
          </Link>
          <div className="border-t pt-2 mt-2">
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 p-2 rounded-md w-full text-left text-red-600 hover:bg-red-50"
            >
              <LogOut className="h-5 w-5" />
              <span>Đăng xuất</span>
            </button>
          </div>
        </nav>
      </div>
    </div>
  );
}
