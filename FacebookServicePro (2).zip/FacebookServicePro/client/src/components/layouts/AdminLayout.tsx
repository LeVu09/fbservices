import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { logout, getCurrentUser } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import {
  PanelsTopLeft,
  UsersIcon,
  PackageIcon,
  CogIcon,
  LogOutIcon,
  ArrowLeftIcon,
  MenuIcon,
  XIcon,
  CreditCardIcon,
} from "lucide-react";

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location, navigate] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    async function fetchUser() {
      try {
        const userData = await getCurrentUser();
        if (!userData || !userData.isAdmin) {
          // Redirect non-admin users
          navigate("/login");
          toast({
            title: "Không có quyền truy cập",
            description: "Bạn không có quyền truy cập vào trang quản trị",
            variant: "destructive",
          });
          return;
        }
        setUser(userData);
      } catch (error) {
        console.error("Failed to fetch user:", error);
        navigate("/login");
      } finally {
        setLoading(false);
      }
    }

    fetchUser();
  }, [navigate, toast]);

  const handleLogout = async () => {
    try {
      await logout();
      queryClient.clear();
      navigate("/login");
      toast({
        title: "Đăng xuất thành công",
        description: "Bạn đã đăng xuất khỏi hệ thống",
      });
    } catch (error) {
      console.error("Logout failed:", error);
      toast({
        title: "Đăng xuất thất bại",
        description: "Có lỗi xảy ra khi đăng xuất",
        variant: "destructive",
      });
    }
  };

  const isActive = (path: string) => {
    return location === path;
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar (desktop) */}
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 bg-gray-800 overflow-y-auto">
          <div className="flex items-center flex-shrink-0 px-4">
            <span className="text-xl font-bold text-white">FB Services</span>
            <span className="ml-2 text-xs bg-primary-600 text-white px-2 py-1 rounded">Admin</span>
          </div>
          <div className="mt-5 flex-1 flex flex-col">
            <nav className="flex-1 px-2 pb-4 space-y-1">
              <Link href="/admin/dashboard">
                <a
                  className={`${
                    isActive("/admin/dashboard")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <PanelsTopLeft className="mr-3 h-6 w-6" />
                  Tổng quan
                </a>
              </Link>
              <Link href="/admin/users">
                <a
                  className={`${
                    isActive("/admin/users")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <UsersIcon className="mr-3 h-6 w-6" />
                  Quản lý người dùng
                </a>
              </Link>
              <Link href="/admin/orders">
                <a
                  className={`${
                    isActive("/admin/orders")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <PackageIcon className="mr-3 h-6 w-6" />
                  Quản lý đơn hàng
                </a>
              </Link>
              <Link href="/admin/services">
                <a
                  className={`${
                    isActive("/admin/services")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <CogIcon className="mr-3 h-6 w-6" />
                  Cài đặt dịch vụ
                </a>
              </Link>
            </nav>
          </div>
          <div className="border-t border-gray-700 p-4">
            <Button
              onClick={handleLogout}
              variant="destructive"
              className="w-full flex items-center justify-center"
            >
              <LogOutIcon className="mr-2 h-4 w-4" />
              Đăng xuất
            </Button>
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              className="w-full mt-2 flex items-center justify-center"
            >
              <ArrowLeftIcon className="mr-2 h-4 w-4" />
              Về trang chính
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-50 ${
          isMobileMenuOpen ? "block" : "hidden"
        } md:hidden`}
      >
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75"></div>
        <div className="fixed inset-y-0 left-0 max-w-xs w-full bg-gray-800 z-50">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button
              type="button"
              className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <span className="sr-only">Close sidebar</span>
              <XIcon className="h-6 w-6 text-white" />
            </button>
          </div>
          <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <div className="flex items-center flex-shrink-0 px-4">
              <span className="text-xl font-bold text-white">FB Services</span>
              <span className="ml-2 text-xs bg-primary-600 text-white px-2 py-1 rounded">
                Admin
              </span>
            </div>
            <nav className="mt-5 flex-1 px-2 space-y-1">
              <Link href="/admin/dashboard">
                <a
                  className={`${
                    isActive("/admin/dashboard")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-base font-medium rounded-md`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <PanelsTopLeft className="mr-3 h-6 w-6" />
                  Tổng quan
                </a>
              </Link>
              <Link href="/admin/users">
                <a
                  className={`${
                    isActive("/admin/users")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-base font-medium rounded-md`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <UsersIcon className="mr-3 h-6 w-6" />
                  Quản lý người dùng
                </a>
              </Link>
              <Link href="/admin/orders">
                <a
                  className={`${
                    isActive("/admin/orders")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-base font-medium rounded-md`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <PackageIcon className="mr-3 h-6 w-6" />
                  Quản lý đơn hàng
                </a>
              </Link>
              <Link href="/admin/services">
                <a
                  className={`${
                    isActive("/admin/services")
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-base font-medium rounded-md`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <CogIcon className="mr-3 h-6 w-6" />
                  Cài đặt dịch vụ
                </a>
              </Link>
            </nav>
          </div>
          <div className="border-t border-gray-700 p-4">
            <Button
              onClick={handleLogout}
              variant="destructive"
              className="w-full flex items-center justify-center"
            >
              <LogOutIcon className="mr-2 h-4 w-4" />
              Đăng xuất
            </Button>
            <Button
              onClick={() => {
                setIsMobileMenuOpen(false);
                navigate("/");
              }}
              variant="outline"
              className="w-full mt-2 flex items-center justify-center"
            >
              <ArrowLeftIcon className="mr-2 h-4 w-4" />
              Về trang chính
            </Button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <div className="md:hidden bg-gray-800 text-white flex items-center justify-between px-4 py-2">
          <div className="flex items-center">
            <span className="text-xl font-bold">FB Services</span>
            <span className="ml-2 text-xs bg-primary-600 text-white px-2 py-1 rounded">
              Admin
            </span>
          </div>
          <button
            type="button"
            className="p-2 rounded-md text-gray-300 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <span className="sr-only">Open sidebar</span>
            <MenuIcon className="h-6 w-6" />
          </button>
        </div>
        <main className="flex-1 relative overflow-y-auto focus:outline-none bg-gray-100">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              {/* Page header */}
              <div className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-semibold text-gray-900">
                  {location === "/admin/dashboard"
                    ? "Tổng quan"
                    : location === "/admin/users"
                    ? "Quản lý người dùng"
                    : location === "/admin/orders"
                    ? "Quản lý đơn hàng"
                    : location === "/admin/services"
                    ? "Cài đặt dịch vụ"
                    : "Dashboard"}
                </h1>
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 hidden md:inline-block">
                    Xin chào,{" "}
                  </span>
                  <span className="text-sm font-medium text-gray-900 ml-1 hidden md:inline-block">
                    {user?.username}
                  </span>
                  <div className="ml-4 relative">
                    <div>
                      <Avatar className="h-8 w-8 bg-primary-600 text-white">
                        <AvatarFallback>
                          {user?.username
                            ?.split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()
                            .substring(0, 2) || "AD"}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                  </div>
                </div>
              </div>

              {/* Page content */}
              <div>{children}</div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
