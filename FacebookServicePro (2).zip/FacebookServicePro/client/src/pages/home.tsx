import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import MainLayout from "@/components/layouts/MainLayout";
import ServicePricing from "@/components/services/ServicePricing";
import ServiceTestimonials from "@/components/services/ServiceTestimonials";
import { apiRequest } from "@/lib/queryClient";
import { Service } from "@shared/schema";
import { ServiceCard } from "@/components/ui/service-card";
import { ShieldCheck, Clock, HeadphonesIcon, DollarSign, Trophy, Unlock } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchServices() {
      try {
        setIsLoading(true);
        const res = await apiRequest("GET", "/api/services");
        const servicesData = await res.json();
        setServices(servicesData);
      } catch (error) {
        console.error("Failed to fetch services:", error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchServices();
  }, []);

  const handleOrderClick = (serviceId: number) => {
    navigate(`/user/create-order?serviceId=${serviceId}`);
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative bg-primary-800 py-16 sm:py-24">
        <div className="absolute inset-0 overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1611162616475-46b635cb6868?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080"
            alt="Social media background"
            className="w-full h-full object-cover opacity-10"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-white text-center">
            Dịch Vụ Phục Hồi & Mở Khóa Tài Khoản Facebook
          </h1>
          <p className="mt-4 max-w-2xl text-center text-primary-100 text-lg">
            Giải pháp nhanh chóng và đáng tin cậy giúp bạn lấy lại quyền truy cập vào tài khoản Facebook của mình.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 w-full max-w-md justify-center">
            <Button
              variant="outline"
              size="lg"
              className="bg-white text-primary-800 hover:bg-gray-50"
              onClick={() => {
                const pricingSection = document.getElementById("pricing");
                if (pricingSection) {
                  pricingSection.scrollIntoView({ behavior: "smooth" });
                }
              }}
            >
              Xem bảng giá
            </Button>
            <Button
              size="lg"
              onClick={() => navigate("/user/create-order")}
            >
              Tạo đơn hàng
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl font-heading font-bold text-gray-900">
              Tại sao chọn dịch vụ của chúng tôi?
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-base text-gray-500">
              Với nhiều năm kinh nghiệm, chúng tôi cung cấp dịch vụ phục hồi tài khoản Facebook nhanh chóng và hiệu quả.
            </p>
          </div>

          <div className="mt-10">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
                  <ShieldCheck className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">An toàn & Bảo mật</h3>
                <p className="mt-2 text-gray-600">
                  Thông tin và dữ liệu của bạn luôn được bảo vệ tuyệt đối trong quá trình phục hồi tài khoản.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Nhanh chóng</h3>
                <p className="mt-2 text-gray-600">
                  Thời gian xử lý nhanh, đảm bảo bạn lấy lại quyền truy cập vào tài khoản trong thời gian ngắn nhất.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
                  <HeadphonesIcon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Hỗ trợ 24/7</h3>
                <p className="mt-2 text-gray-600">
                  Đội ngũ hỗ trợ luôn sẵn sàng giải đáp mọi thắc mắc và hỗ trợ bạn bất cứ lúc nào.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
                  <DollarSign className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Giá cả hợp lý</h3>
                <p className="mt-2 text-gray-600">
                  Chúng tôi cung cấp dịch vụ với mức giá cạnh tranh và minh bạch, không có phí ẩn.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
                  <Trophy className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Tỷ lệ thành công cao</h3>
                <p className="mt-2 text-gray-600">
                  Đội ngũ chuyên gia giàu kinh nghiệm đảm bảo tỷ lệ thành công cao trong việc phục hồi tài khoản.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="w-12 h-12 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mb-4">
                  <Unlock className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Đa dạng dịch vụ</h3>
                <p className="mt-2 text-gray-600">
                  Cung cấp nhiều dịch vụ khác nhau từ mở khóa tài khoản đến khôi phục tài khoản bị hack.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl font-heading font-bold text-gray-900">
              Dịch vụ của chúng tôi
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-base text-gray-500">
              Chúng tôi cung cấp các dịch vụ chuyên nghiệp giúp khôi phục và bảo vệ tài khoản Facebook của bạn.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {isLoading ? (
              <div className="col-span-full flex justify-center py-12">
                <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
              </div>
            ) : (
              services.slice(0, 3).map((service) => (
                <ServiceCard
                  key={service.id}
                  id={service.id}
                  title={service.name}
                  description={service.description}
                  price={service.price}
                  processingTime={service.processingTime}
                  imageSrc={
                    service.id === 1
                      ? "https://images.unsplash.com/photo-1611162616071-b39a2ec055fb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450"
                      : service.id === 2
                      ? "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450"
                      : "https://images.unsplash.com/photo-1639322537228-f710d846310a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=450"
                  }
                  badge={service.id === 1 ? "Phổ biến" : undefined}
                  features={[
                    `Xử lý trong ${service.processingTime}`,
                    "Tỷ lệ thành công cao",
                    "Hỗ trợ sau khi xử lý",
                  ]}
                  onOrderClick={() => handleOrderClick(service.id)}
                />
              ))
            )}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <ServiceTestimonials />
      
      {/* Pricing Table */}
      <ServicePricing />

      {/* Stats Section */}
      <section className="py-12 bg-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            <div className="text-center">
              <h3 className="text-4xl font-bold">5000+</h3>
              <p className="mt-2 text-primary-200">Tài khoản đã phục hồi</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl font-bold">98%</h3>
              <p className="mt-2 text-primary-200">Tỷ lệ thành công</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl font-bold">24/7</h3>
              <p className="mt-2 text-primary-200">Hỗ trợ khách hàng</p>
            </div>
            <div className="text-center">
              <h3 className="text-4xl font-bold">2000+</h3>
              <p className="mt-2 text-primary-200">Khách hàng hài lòng</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl font-heading font-bold text-gray-900">
              Liên hệ với chúng tôi
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-base text-gray-500">
              Bạn có câu hỏi? Hãy liên hệ với chúng tôi, đội ngũ hỗ trợ sẽ phản hồi trong thời gian sớm nhất.
            </p>
          </div>

          <div className="mt-10 max-w-3xl mx-auto">
            <form className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                  Họ và tên
                </label>
                <input
                  type="text"
                  name="first-name"
                  id="first-name"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="Nhập họ và tên của bạn"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="you@example.com"
                />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
                  Tiêu đề
                </label>
                <input
                  type="text"
                  name="subject"
                  id="subject"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="Tiêu đề tin nhắn"
                />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                  Nội dung
                </label>
                <textarea
                  name="message"
                  id="message"
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
                  placeholder="Nhập nội dung tin nhắn của bạn"
                ></textarea>
              </div>
              <div className="sm:col-span-2">
                <Button className="w-full" size="lg">
                  Gửi tin nhắn
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
