import AdminLayout from "@/components/layouts/AdminLayout";
import OrdersTable from "@/components/admin/OrdersTable";

export default function AdminOrders() {
  return (
    <AdminLayout>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Quản lý đơn hàng</h2>
        </div>
        <p className="text-gray-500">
          Quản lý và cập nhật trạng thái các đơn hàng dịch vụ Facebook.
        </p>
      </div>

      <div className="mt-6">
        <OrdersTable />
      </div>
    </AdminLayout>
  );
}
