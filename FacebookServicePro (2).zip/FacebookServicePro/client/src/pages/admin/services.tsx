import { useState, useEffect } from "react";
import AdminLayout from "@/components/layouts/AdminLayout";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Service } from "@shared/schema";
import ServiceForm from "@/components/admin/ServiceForm";
import { queryClient } from "@/lib/queryClient";
import { Toggle } from "@/components/ui/toggle";
import { Edit, Plus } from "lucide-react";

export default function AdminServices() {
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      setIsLoading(true);
      const res = await apiRequest("GET", "/api/services");
      const servicesData = await res.json();
      setServices(servicesData);
    } catch (error) {
      console.error("Failed to fetch services:", error);
      toast({
        title: "Lỗi khi tải dữ liệu",
        description: "Không thể tải danh sách dịch vụ. Vui lòng thử lại sau.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreate = () => {
    setSelectedService(null);
    setIsCreating(true);
    setIsFormOpen(true);
  };

  const handleEdit = (service: Service) => {
    setSelectedService(service);
    setIsCreating(false);
    setIsFormOpen(true);
  };

  const handleToggleActive = async (service: Service) => {
    try {
      const res = await apiRequest("PATCH", `/api/services/${service.id}`, {
        isActive: !service.isActive,
      });
      
      const updatedService = await res.json();
      
      setServices(services.map(s => s.id === updatedService.id ? updatedService : s));
      
      toast({
        title: `Dịch vụ đã được ${updatedService.isActive ? 'kích hoạt' : 'vô hiệu hóa'}`,
        description: `${updatedService.name} đã được ${updatedService.isActive ? 'kích hoạt' : 'vô hiệu hóa'} thành công.`,
      });
      
      // Invalidate services query to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
    } catch (error) {
      console.error("Failed to toggle service status:", error);
      toast({
        title: "Thao tác thất bại",
        description: "Không thể thay đổi trạng thái dịch vụ. Vui lòng thử lại.",
        variant: "destructive",
      });
    }
  };

  const handleFormSuccess = (service: Service, isNew: boolean) => {
    if (isNew) {
      setServices([...services, service]);
    } else {
      setServices(services.map(s => s.id === service.id ? service : s));
    }
    
    setIsFormOpen(false);
    
    // Invalidate services query to refresh data
    queryClient.invalidateQueries({ queryKey: ["/api/services"] });
    
    toast({
      title: isNew ? "Tạo dịch vụ thành công" : "Cập nhật dịch vụ thành công",
      description: isNew ? "Dịch vụ mới đã được tạo thành công." : `${service.name} đã được cập nhật thành công.`,
    });
  };

  const columns = [
    {
      header: "ID",
      accessorKey: "id" as keyof Service,
    },
    {
      header: "Tên dịch vụ",
      accessorKey: "name" as keyof Service,
    },
    {
      header: "Mô tả",
      accessorKey: "description" as keyof Service,
      cell: (row: Service) => (
        <div className="max-w-md truncate" title={row.description}>
          {row.description}
        </div>
      ),
    },
    {
      header: "Giá (Coins)",
      accessorKey: "price" as keyof Service,
      cell: (row: Service) => row.price.toLocaleString(),
    },
    {
      header: "Thời gian xử lý",
      accessorKey: "processingTime" as keyof Service,
    },
    {
      header: "Trạng thái",
      accessorKey: "isActive" as keyof Service,
      cell: (row: Service) => (
        row.isActive ? 
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Hoạt động</Badge> : 
          <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Vô hiệu hóa</Badge>
      ),
    },
    {
      header: "Thao tác",
      accessorKey: "actions",
      cell: (row: Service) => (
        <div className="flex space-x-2">
          <Button 
            onClick={() => handleEdit(row)} 
            variant="outline" 
            size="sm"
            className="h-8 w-8 p-0"
          >
            <Edit className="h-4 w-4" />
            <span className="sr-only">Chỉnh sửa</span>
          </Button>
          <Toggle
            pressed={row.isActive}
            onPressedChange={() => handleToggleActive(row)}
            size="sm"
            aria-label="Trạng thái hoạt động"
          >
            {row.isActive ? "Đang hoạt động" : "Đã vô hiệu hóa"}
          </Toggle>
        </div>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold">Quản lý dịch vụ</h2>
            <p className="text-gray-500">
              Quản lý các dịch vụ mở khóa và phục hồi tài khoản Facebook
            </p>
          </div>
          <Button onClick={handleCreate}>
            <Plus className="mr-2 h-4 w-4" /> Thêm dịch vụ mới
          </Button>
        </div>
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Danh sách dịch vụ</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable
            data={services}
            columns={columns}
            searchKey="name"
            pageSize={10}
          />
        </CardContent>
      </Card>

      {/* Service Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {isCreating ? "Thêm dịch vụ mới" : "Chỉnh sửa dịch vụ"}
            </DialogTitle>
          </DialogHeader>
          <ServiceForm
            service={selectedService}
            onSuccess={(service) => handleFormSuccess(service, isCreating)}
            onCancel={() => setIsFormOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
