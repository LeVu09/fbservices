import { useState, useEffect } from "react";
import AdminLayout from "@/components/layouts/AdminLayout";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { User, Order, Service } from "@shared/schema";
import { Users, Package, CreditCard, CheckCircle } from "lucide-react";

export default function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        
        // Fetch all data
        const [usersRes, ordersRes, servicesRes] = await Promise.all([
          apiRequest("GET", "/api/users"),
          apiRequest("GET", "/api/orders"),
          apiRequest("GET", "/api/services"),
        ]);
        
        const usersData = await usersRes.json();
        const ordersData = await ordersRes.json();
        const servicesData = await servicesRes.json();
        
        setUsers(usersData);
        setOrders(ordersData);
        setServices(servicesData);
      } catch (error) {
        console.error("Failed to fetch dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, []);

  const pendingOrders = orders.filter(order => order.status === "pending");
  const completedOrders = orders.filter(order => order.status === "completed");
  
  // Calculate total revenue
  const totalRevenue = completedOrders.reduce((sum, order) => sum + order.price, 0);
  
  // Calculate success rate
  const successRate = orders.length > 0 
    ? Math.round((completedOrders.length / orders.length) * 100) 
    : 0;

  const getUserName = (userId: number) => {
    const user = users.find((u) => u.id === userId);
    return user ? user.username : `User #${userId}`;
  };

  const getServiceName = (serviceId: number) => {
    const service = services.find((s) => s.id === serviceId);
    return service ? service.name : `Service #${serviceId}`;
  };

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN");
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Đang chờ</Badge>;
      case "processing":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Đang xử lý</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Hoàn thành</Badge>;
      case "failed":
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Thất bại</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      {/* Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Tổng người dùng"
          value={users.length}
          icon={<Users className="h-6 w-6" />}
          linkText="Xem tất cả"
          linkHref="/admin/users"
          iconColor="bg-primary-100 text-primary-600"
        />
        <StatsCard
          title="Đơn hàng mới"
          value={pendingOrders.length}
          icon={<Package className="h-6 w-6" />}
          linkText="Xem tất cả"
          linkHref="/admin/orders"
          iconColor="bg-orange-100 text-orange-600"
        />
        <StatsCard
          title="Tổng doanh thu"
          value={`${totalRevenue.toLocaleString()} ₫`}
          icon={<CreditCard className="h-6 w-6" />}
          iconColor="bg-green-100 text-green-600"
        />
        <StatsCard
          title="Tỷ lệ thành công"
          value={`${successRate}%`}
          icon={<CheckCircle className="h-6 w-6" />}
          iconColor="bg-blue-100 text-blue-600"
        />
      </div>

      {/* Recent orders */}
      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Đơn hàng gần đây</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-300">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">ID</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Dịch vụ</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Người dùng</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Ngày tạo</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Giá</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Trạng thái</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 bg-white">
                  {orders.slice(0, 5).map((order) => (
                    <tr key={order.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">#{order.id}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900">{getServiceName(order.serviceId)}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900">
                        <div>{getUserName(order.userId)}</div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{formatDate(order.createdAt)}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{order.price.toLocaleString()} ₫</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">{getStatusBadge(order.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Service stats */}
      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Thống kê dịch vụ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-300">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">ID</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Tên dịch vụ</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Giá</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Số đơn hàng</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Doanh thu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 bg-white">
                  {services.map((service) => {
                    const serviceOrders = orders.filter(o => o.serviceId === service.id);
                    const serviceCompletedOrders = serviceOrders.filter(o => o.status === "completed");
                    const serviceRevenue = serviceCompletedOrders.reduce((sum, o) => sum + o.price, 0);
                    
                    return (
                      <tr key={service.id}>
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">{service.id}</td>
                        <td className="px-3 py-4 text-sm text-gray-900">{service.name}</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{service.price.toLocaleString()} ₫</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{serviceOrders.length}</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900 font-medium">{serviceRevenue.toLocaleString()} ₫</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
