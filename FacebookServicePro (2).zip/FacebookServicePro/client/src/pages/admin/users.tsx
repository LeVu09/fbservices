import AdminLayout from "@/components/layouts/AdminLayout";
import UsersTable from "@/components/admin/UsersTable";

export default function AdminUsers() {
  return (
    <AdminLayout>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Quản lý người dùng</h2>
        </div>
        <p className="text-gray-500">
          Quản lý tất cả người dùng trong hệ thống và thực hiện các thao tác như nạp coin.
        </p>
      </div>

      <div className="mt-6">
        <UsersTable />
      </div>
    </AdminLayout>
  );
}
