import MainLayout from "@/components/layouts/MainLayout";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

const faqs = [
  {
    question: "Dịch vụ mở checkpoint Facebook là gì?",
    answer: "Dịch vụ mở checkpoint Facebook là dịch vụ giúp người dùng khôi phục quyền truy cập vào tài khoản Facebook bị chặn do vi phạm chính sách hoặc các vấn đề bảo mật. Đội ngũ kỹ thuật của chúng tôi sẽ thực hiện các biện pháp an toàn và hợp pháp để giúp bạn lấy lại quyền truy cập vào tài khoản."
  },
  {
    question: "Mất bao lâu để mở khóa tài khoản Facebook của tôi?",
    answer: "Thời gian mở khóa tài khoản phụ thuộc vào mức độ phức tạp của vấn đề. Đối với các trường hợp checkpoint cơ bản, thời gian xử lý thường từ 1-3 ngày. Trường hợp phức tạp hơn như tài khoản bị khóa vĩnh viễn có thể mất từ 5-7 ngày, hoặc lâu hơn trong một số trường hợp đặc biệt."
  },
  {
    question: "Tỷ lệ thành công của dịch vụ là bao nhiêu?",
    answer: "Tỷ lệ thành công của dịch vụ chúng tôi đạt khoảng 95% đối với các trường hợp checkpoint cơ bản và khoảng 80% đối với các trường hợp phức tạp hơn. Chúng tôi cam kết nỗ lực hết sức để khôi phục tài khoản của bạn và chỉ thu phí khi thành công."
  },
  {
    question: "Quy trình đặt dịch vụ như thế nào?",
    answer: "Quy trình đặt dịch vụ rất đơn giản: (1) Đăng ký tài khoản trên hệ thống của chúng tôi, (2) Chọn dịch vụ phù hợp với vấn đề của bạn, (3) Cung cấp thông tin cần thiết về tài khoản Facebook, (4) Thanh toán phí dịch vụ, (5) Đội ngũ kỹ thuật sẽ bắt đầu tiến hành xử lý và liên hệ với bạn khi hoàn thành."
  },
  {
    question: "Tôi cần cung cấp những thông tin gì?",
    answer: "Để thực hiện dịch vụ, chúng tôi cần: (1) Email đăng nhập Facebook, (2) URL tài khoản Facebook, (3) Mô tả chi tiết vấn đề bạn đang gặp phải. Lưu ý: Chúng tôi KHÔNG yêu cầu mật khẩu Facebook của bạn và sẽ liên hệ nếu cần thêm thông tin."
  },
  {
    question: "Dịch vụ của các bạn có an toàn không?",
    answer: "Có, dịch vụ của chúng tôi hoàn toàn an toàn. Chúng tôi tuân thủ các biện pháp bảo mật cao nhất để bảo vệ thông tin cá nhân của khách hàng. Chúng tôi không yêu cầu mật khẩu Facebook và chỉ sử dụng thông tin bạn cung cấp cho mục đích khôi phục tài khoản."
  },
  {
    question: "Làm thế nào để thanh toán cho dịch vụ?",
    answer: "Chúng tôi sử dụng hệ thống coin nội bộ. Bạn cần nạp coin vào tài khoản và sử dụng số dư để thanh toán cho dịch vụ. Hiện tại, bạn cần liên hệ với admin để nạp coin vào tài khoản của mình."
  },
  {
    question: "Có bảo hành sau khi mở khóa tài khoản không?",
    answer: "Có, chúng tôi cung cấp bảo hành 30 ngày sau khi hoàn thành dịch vụ. Trong thời gian này, nếu tài khoản của bạn gặp lại vấn đề tương tự, chúng tôi sẽ hỗ trợ miễn phí. Tuy nhiên, bảo hành không áp dụng cho các vi phạm mới sau khi khôi phục tài khoản."
  },
  {
    question: "Nếu không thể khôi phục tài khoản, tôi có được hoàn tiền không?",
    answer: "Có, chúng tôi có chính sách hoàn tiền nếu không thể khôi phục tài khoản của bạn. Tùy thuộc vào dịch vụ và mức độ công việc đã thực hiện, bạn sẽ được hoàn lại từ 70% đến 100% số tiền đã thanh toán."
  },
  {
    question: "Tôi có thể liên hệ hỗ trợ bằng cách nào?",
    answer: "Bạn có thể liên hệ với đội ngũ hỗ trợ của chúng tôi qua email, chat trực tuyến trên website, hoặc gọi điện trực tiếp. Đội ngũ hỗ trợ khách hàng làm việc 24/7 và sẽ phản hồi bạn trong thời gian sớm nhất."
  }
];

export default function FAQ() {
  const [, navigate] = useLocation();

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Câu hỏi thường gặp</h1>
          <p className="text-lg text-gray-600">
            Tìm câu trả lời cho những câu hỏi phổ biến về dịch vụ của chúng tôi
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border border-gray-200 rounded-lg overflow-hidden">
              <AccordionTrigger className="px-6 py-4 hover:bg-gray-50 text-left font-medium text-gray-900">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-4 pt-2 text-gray-600">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            Bạn không tìm thấy câu trả lời cho câu hỏi của mình?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="outline"
              onClick={() => navigate("/contact")}
            >
              Liên hệ với chúng tôi
            </Button>
            <Button
              onClick={() => navigate("/user/create-order")}
            >
              Đặt dịch vụ ngay
            </Button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}