import { useState, useEffect } from "react";
import MainLayout from "@/components/layouts/MainLayout";
import UserNavbar from "@/components/user/UserNavbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentUser } from "@/lib/auth";
import { User, Transaction } from "@shared/schema";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function UserWallet() {
  const [user, setUser] = useState<User | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        
        // Fetch user data and transactions
        const userData = await getCurrentUser();
        setUser(userData);
        
        const transactionsRes = await apiRequest("GET", "/api/transactions");
        const transactionsData = await transactionsRes.json();
        setTransactions(transactionsData);
      } catch (error) {
        console.error("Failed to fetch wallet data:", error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, []);

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN") + " " + date.toLocaleTimeString("vi-VN");
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Ví của tôi</h1>

          <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <UserNavbar />
            </div>

            <div className="lg:col-span-3 space-y-6">
              {/* Wallet balance */}
              <Card>
                <CardHeader>
                  <CardTitle>Số dư tài khoản</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Số dư hiện tại</p>
                      <p className="text-3xl font-bold text-primary-600">{user?.coins?.toLocaleString() || 0} coins</p>
                    </div>
                    <Button>Nạp thêm coin</Button>
                  </div>
                </CardContent>
              </Card>

              {/* Deposit instructions */}
              <Card>
                <CardHeader>
                  <CardTitle>Nạp coin</CardTitle>
                  <CardDescription>
                    Hướng dẫn nạp coin vào tài khoản
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Lưu ý</AlertTitle>
                    <AlertDescription>
                      Sau khi chuyển khoản, vui lòng liên hệ với admin để xác nhận và được cộng coin vào tài khoản.
                    </AlertDescription>
                  </Alert>

                  <div className="bg-gray-50 p-4 rounded-md">
                    <p className="font-medium text-gray-800">Thông tin chuyển khoản:</p>
                    <div className="mt-2 space-y-2 text-sm">
                      <p><span className="font-medium">Ngân hàng:</span> Vietcombank</p>
                      <p><span className="font-medium">Số tài khoản:</span> 1234 5678 9012</p>
                      <p><span className="font-medium">Tên tài khoản:</span> NGUYEN VAN A</p>
                      <p><span className="font-medium">Nội dung:</span> NAP FB {user?.email || "[email_của_bạn]"}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-500">Hoặc liên hệ trực tiếp với chúng tôi qua:</p>
                    <div className="mt-2 space-x-4">
                      <Button variant="outline" size="sm">
                        <svg className="h-4 w-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
                        </svg>
                        Facebook
                      </Button>
                      <Button variant="outline" size="sm">
                        <svg className="h-4 w-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12.335 0c1.617 0 3.225.085 4.848.254 1.623.17 3.085.514 4.387 1.035.362.148.695.315.991.498.295.183.554.392.774.629.222.237.405.501.547.791.142.29.213.608.213.953 0 .297-.033.564-.099.801-.065.237-.154.453-.266.646-.112.194-.242.362-.388.503-.147.142-.294.263-.441.364v.182c.147.1.295.222.441.364.146.142.276.31.388.503.112.194.201.41.266.647.066.237.099.504.099.801 0 .345-.071.663-.213.953a2.385 2.385 0 01-.547.791c-.22.237-.479.446-.774.629a4.692 4.692 0 01-.991.498c-1.302.522-2.764.866-4.387 1.035-1.623.17-3.231.254-4.823.254-1.593 0-3.201-.085-4.824-.254-1.623-.17-3.086-.513-4.387-1.035a4.693 4.693 0 01-.992-.498 3.264 3.264 0 01-.774-.629 2.385 2.385 0 01-.547-.791c-.142-.29-.213-.608-.213-.953 0-.297.033-.564.099-.801.066-.237.154-.453.266-.647.113-.194.243-.361.388-.503.147-.142.295-.264.441-.364v-.182a3.438 3.438 0 01-.441-.364c-.145-.141-.275-.309-.388-.503a2.235 2.235 0 01-.266-.646c-.066-.237-.099-.504-.099-.801 0-.345.071-.663.213-.953.142-.29.325-.554.547-.791.22-.237.479-.446.774-.629.296-.183.63-.35.992-.498 1.301-.521 2.764-.865 4.387-1.035C9.134.085 10.742 0 12.335 0z" />
                        </svg>
                        Telegram
                      </Button>
                      <Button variant="outline" size="sm">
                        <svg className="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        Email
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Transaction history */}
              <Card>
                <CardHeader>
                  <CardTitle>Lịch sử giao dịch</CardTitle>
                  <CardDescription>
                    Danh sách các giao dịch coin trong tài khoản của bạn
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {transactions.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3">Mã giao dịch</th>
                            <th scope="col" className="px-6 py-3">Loại</th>
                            <th scope="col" className="px-6 py-3">Thời gian</th>
                            <th scope="col" className="px-6 py-3">Số lượng</th>
                            <th scope="col" className="px-6 py-3">Ghi chú</th>
                          </tr>
                        </thead>
                        <tbody>
                          {transactions.map((transaction) => (
                            <tr key={transaction.id} className="bg-white border-b hover:bg-gray-50">
                              <td className="px-6 py-4">#{transaction.id}</td>
                              <td className="px-6 py-4">
                                {transaction.type === "deposit" ? (
                                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Nạp vào</Badge>
                                ) : (
                                  <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Sử dụng</Badge>
                                )}
                              </td>
                              <td className="px-6 py-4">{formatDate(transaction.createdAt)}</td>
                              <td className={`px-6 py-4 font-medium ${transaction.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                                {transaction.amount > 0 ? "+" : ""}{transaction.amount.toLocaleString()}
                              </td>
                              <td className="px-6 py-4">{transaction.description}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      Chưa có giao dịch nào
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
