import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import MainLayout from "@/components/layouts/MainLayout";
import UserNavbar from "@/components/user/UserNavbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Order, Service } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export default function UserOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [location] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        
        // Fetch orders and services
        const [ordersRes, servicesRes] = await Promise.all([
          apiRequest("GET", "/api/orders"),
          apiRequest("GET", "/api/services"),
        ]);
        
        const ordersData = await ordersRes.json();
        const servicesData = await servicesRes.json();
        
        setOrders(ordersData);
        setServices(servicesData);
        
        // Check if there's an order ID in URL params
        const searchParams = new URLSearchParams(location.split('?')[1]);
        const orderId = searchParams.get('id');
        if (orderId) {
          const order = ordersData.find(o => o.id === parseInt(orderId));
          if (order) {
            setSelectedOrder(order);
            setIsDetailsOpen(true);
          }
        }
      } catch (error) {
        console.error("Failed to fetch data:", error);
        toast({
          title: "Lỗi khi tải dữ liệu",
          description: "Không thể tải danh sách đơn hàng. Vui lòng thử lại sau.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [location, toast]);

  const getServiceName = (serviceId: number) => {
    const service = services.find(s => s.id === serviceId);
    return service ? service.name : `Dịch vụ #${serviceId}`;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Đang chờ</Badge>;
      case "processing":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Đang xử lý</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Hoàn thành</Badge>;
      case "failed":
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Thất bại</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN") + " " + date.toLocaleTimeString("vi-VN");
  };

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setIsDetailsOpen(true);
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Đơn hàng của tôi</h1>

          <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <UserNavbar />
            </div>

            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle>Danh sách đơn hàng</CardTitle>
                  <CardDescription>
                    Quản lý các đơn hàng dịch vụ của bạn
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {orders.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3">Mã đơn</th>
                            <th scope="col" className="px-6 py-3">Dịch vụ</th>
                            <th scope="col" className="px-6 py-3">Ngày tạo</th>
                            <th scope="col" className="px-6 py-3">Giá</th>
                            <th scope="col" className="px-6 py-3">Trạng thái</th>
                            <th scope="col" className="px-6 py-3">Thao tác</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orders.map((order) => (
                            <tr key={order.id} className="bg-white border-b hover:bg-gray-50">
                              <td className="px-6 py-4">#{order.id}</td>
                              <td className="px-6 py-4">{getServiceName(order.serviceId)}</td>
                              <td className="px-6 py-4">{formatDate(order.createdAt)}</td>
                              <td className="px-6 py-4">{order.price.toLocaleString()} ₫</td>
                              <td className="px-6 py-4">{getStatusBadge(order.status)}</td>
                              <td className="px-6 py-4">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleViewDetails(order)}
                                >
                                  Chi tiết
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-gray-500 mb-4">Bạn chưa có đơn hàng nào</p>
                      <Button onClick={() => window.location.href = "/user/create-order"}>
                        Tạo đơn hàng mới
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Chi tiết đơn hàng #{selectedOrder.id}</DialogTitle>
              <DialogDescription>
                {getServiceName(selectedOrder.serviceId)}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">Trạng thái</p>
                  <p className="mt-1">{getStatusBadge(selectedOrder.status)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Giá</p>
                  <p className="mt-1 font-semibold">{selectedOrder.price.toLocaleString()} ₫</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Ngày tạo</p>
                  <p className="mt-1">{formatDate(selectedOrder.createdAt)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Cập nhật lần cuối</p>
                  <p className="mt-1">{formatDate(selectedOrder.updatedAt)}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Facebook Email</p>
                <p className="mt-1">{selectedOrder.fbEmail}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Facebook URL</p>
                <p className="mt-1">{selectedOrder.fbUrl}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Mô tả vấn đề</p>
                <p className="mt-1 text-gray-700">{selectedOrder.description}</p>
              </div>
              
              {/* Order Timeline */}
              <div className="border-t pt-4 mt-4">
                <h4 className="font-medium text-gray-900 mb-4">Tiến trình xử lý</h4>
                <div className="relative">
                  <div className="absolute top-0 bottom-0 left-2.5 w-0.5 bg-gray-200"></div>
                  <div className="space-y-6">
                    <div className="relative flex items-start">
                      <div className="h-5 w-5 rounded-full bg-primary-600 flex items-center justify-center mt-0.5 z-10">
                        <div className="h-2 w-2 rounded-full bg-white"></div>
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-900">Đơn hàng được tạo</p>
                        <p className="text-sm text-gray-500">{formatDate(selectedOrder.createdAt)}</p>
                      </div>
                    </div>
                    {selectedOrder.status !== "pending" && (
                      <div className="relative flex items-start">
                        <div className="h-5 w-5 rounded-full bg-blue-600 flex items-center justify-center mt-0.5 z-10">
                          <div className="h-2 w-2 rounded-full bg-white"></div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-900">Đang xử lý</p>
                          <p className="text-sm text-gray-500">{formatDate(selectedOrder.updatedAt)}</p>
                        </div>
                      </div>
                    )}
                    {(selectedOrder.status === "completed" || selectedOrder.status === "failed") && (
                      <div className="relative flex items-start">
                        <div className={`h-5 w-5 rounded-full ${selectedOrder.status === "completed" ? "bg-green-600" : "bg-red-600"} flex items-center justify-center mt-0.5 z-10`}>
                          <div className="h-2 w-2 rounded-full bg-white"></div>
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-900">
                            {selectedOrder.status === "completed" ? "Hoàn thành" : "Thất bại"}
                          </p>
                          <p className="text-sm text-gray-500">{formatDate(selectedOrder.updatedAt)}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
                Đóng
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </MainLayout>
  );
}
