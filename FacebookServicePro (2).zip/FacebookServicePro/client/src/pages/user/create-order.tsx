import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import MainLayout from "@/components/layouts/MainLayout";
import UserNavbar from "@/components/user/UserNavbar";
import CreateOrderForm from "@/components/services/CreateOrderForm";
import { getCurrentUser } from "@/lib/auth";

export default function CreateOrder() {
  const [isLoading, setIsLoading] = useState(true);
  const [location, navigate] = useLocation();
  
  // Extract serviceId from URL if present
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const serviceId = searchParams.get('serviceId');

  useEffect(() => {
    async function checkAuth() {
      try {
        setIsLoading(true);
        const user = await getCurrentUser();
        if (!user) {
          navigate("/login");
        }
      } catch (error) {
        console.error("Auth check failed:", error);
        navigate("/login");
      } finally {
        setIsLoading(false);
      }
    }

    checkAuth();
  }, [navigate]);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Tạo đơn hàng mới</h1>

          <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <UserNavbar />
            </div>

            <div className="lg:col-span-3">
              <CreateOrderForm preselectedServiceId={serviceId || undefined} />
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
