import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import MainLayout from "@/components/layouts/MainLayout";
import UserNavbar from "@/components/user/UserNavbar";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentUser } from "@/lib/auth";
import { User, Order } from "@shared/schema";
import { User as UserIcon, Package, CreditCard, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function UserDashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [, navigate] = useLocation();

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        
        // Fetch user data
        const userData = await getCurrentUser();
        setUser(userData);
        
        // Fetch user orders
        const ordersRes = await apiRequest("GET", "/api/orders");
        const ordersData = await ordersRes.json();
        setOrders(ordersData);
      } catch (error) {
        console.error("Failed to fetch user data:", error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, []);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Đang chờ</Badge>;
      case "processing":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">Đang xử lý</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Hoàn thành</Badge>;
      case "failed":
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Thất bại</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const pendingOrders = orders.filter(order => order.status === "pending" || order.status === "processing");
  const completedOrders = orders.filter(order => order.status === "completed");

  const formatDate = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("vi-VN");
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Bảng điều khiển</h1>

          <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <UserNavbar />
            </div>

            <div className="lg:col-span-3 space-y-6">
              {/* User stats */}
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
                <StatsCard
                  title="Thông tin tài khoản"
                  value={user?.username || ""}
                  icon={<UserIcon className="h-6 w-6" />}
                  description={user?.email || ""}
                  iconColor="bg-primary-100 text-primary-600"
                />
                <StatsCard
                  title="Đơn hàng đang xử lý"
                  value={pendingOrders.length}
                  icon={<Package className="h-6 w-6" />}
                  linkText="Xem tất cả"
                  linkHref="/user/orders"
                  iconColor="bg-orange-100 text-orange-600"
                />
                <StatsCard
                  title="Số dư tài khoản"
                  value={`${user?.coins?.toLocaleString() || 0} coin`}
                  icon={<CreditCard className="h-6 w-6" />}
                  linkText="Nạp thêm"
                  linkHref="/user/wallet"
                  iconColor="bg-green-100 text-green-600"
                />
              </div>

              {/* Quick actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Thao tác nhanh</CardTitle>
                  <CardDescription>Các thao tác phổ biến bạn có thể thực hiện</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-6 sm:grid-cols-2">
                  <Button 
                    onClick={() => navigate("/user/create-order")} 
                    className="justify-start h-auto py-4"
                    variant="outline"
                  >
                    <div className="flex items-center">
                      <div className="mr-4 bg-primary-100 p-2 rounded-full">
                        <Package className="h-5 w-5 text-primary-600" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium">Tạo đơn hàng mới</div>
                        <div className="text-sm text-gray-500">Đặt dịch vụ khôi phục tài khoản Facebook</div>
                      </div>
                    </div>
                    <ArrowRight className="ml-auto h-5 w-5 text-gray-400" />
                  </Button>
                  <Button 
                    onClick={() => navigate("/user/wallet")} 
                    className="justify-start h-auto py-4"
                    variant="outline"
                  >
                    <div className="flex items-center">
                      <div className="mr-4 bg-primary-100 p-2 rounded-full">
                        <CreditCard className="h-5 w-5 text-primary-600" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium">Nạp coin vào tài khoản</div>
                        <div className="text-sm text-gray-500">Nạp thêm coin để sử dụng dịch vụ</div>
                      </div>
                    </div>
                    <ArrowRight className="ml-auto h-5 w-5 text-gray-400" />
                  </Button>
                </CardContent>
              </Card>

              {/* Recent orders */}
              <Card>
                <CardHeader>
                  <CardTitle>Đơn hàng gần đây</CardTitle>
                  <CardDescription>
                    Danh sách các đơn hàng gần đây của bạn
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {orders.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3">Mã đơn</th>
                            <th scope="col" className="px-6 py-3">Dịch vụ</th>
                            <th scope="col" className="px-6 py-3">Ngày tạo</th>
                            <th scope="col" className="px-6 py-3">Giá</th>
                            <th scope="col" className="px-6 py-3">Trạng thái</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orders.slice(0, 5).map((order) => (
                            <tr key={order.id} className="bg-white border-b hover:bg-gray-50 cursor-pointer" onClick={() => navigate(`/user/orders?id=${order.id}`)}>
                              <td className="px-6 py-4">#{order.id}</td>
                              <td className="px-6 py-4">{order.serviceId}</td>
                              <td className="px-6 py-4">{formatDate(order.createdAt)}</td>
                              <td className="px-6 py-4">{order.price.toLocaleString()} ₫</td>
                              <td className="px-6 py-4">{getStatusBadge(order.status)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      Bạn chưa có đơn hàng nào
                    </div>
                  )}
                </CardContent>
                {orders.length > 0 && (
                  <CardFooter className="justify-end">
                    <Button variant="ghost" onClick={() => navigate("/user/orders")}>
                      Xem tất cả đơn hàng <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                )}
              </Card>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
