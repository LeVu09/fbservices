import { useEffect } from 'react';
import { useLocation } from 'wouter';
import MainLayout from '@/components/layouts/MainLayout';
import LoginForm from '@/components/auth/LoginForm';
import { getCurrentUser } from '@/lib/auth';

export default function Login() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Check if user is already logged in
    async function checkAuth() {
      try {
        const user = await getCurrentUser();
        if (user) {
          // Redirect to dashboard if already logged in
          if (user.isAdmin) {
            navigate('/admin/dashboard');
          } else {
            navigate('/user/dashboard');
          }
        }
      } catch (error) {
        console.error('Auth check failed:', error);
      }
    }

    checkAuth();
  }, [navigate]);

  return (
    <MainLayout>
      <div className="max-w-md mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <LoginForm 
          onSuccess={() => {
            // Success callback is handled in the form component
          }}
        />
      </div>
    </MainLayout>
  );
}
