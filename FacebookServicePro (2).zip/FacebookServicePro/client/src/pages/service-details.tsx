import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import MainLayout from "@/components/layouts/MainLayout";
import { apiRequest } from "@/lib/queryClient";
import { Service } from "@shared/schema";
import { Clock, Check, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function ServiceDetails() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [service, setService] = useState<Service | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchServiceDetails() {
      try {
        setIsLoading(true);
        setError(null);
        
        const res = await apiRequest("GET", `/api/services/${id}`);
        
        if (!res.ok) {
          throw new Error("Không thể tải thông tin dịch vụ. Vui lòng thử lại sau.");
        }
        
        const serviceData = await res.json();
        setService(serviceData);
      } catch (error) {
        console.error("Failed to fetch service details:", error);
        setError("Không thể tải thông tin dịch vụ. Vui lòng thử lại sau.");
      } finally {
        setIsLoading(false);
      }
    }

    if (id) {
      fetchServiceDetails();
    }
  }, [id]);

  const handleOrderClick = () => {
    if (service) {
      navigate(`/user/create-order?serviceId=${service.id}`);
    }
  };

  // Helper function to get image based on service ID
  const getServiceImage = (serviceId: number) => {
    switch (serviceId) {
      case 1:
        return "https://images.unsplash.com/photo-1611162616071-b39a2ec055fb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600";
      case 2:
        return "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600";
      case 3:
        return "https://images.unsplash.com/photo-1639322537228-f710d846310a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600";
      case 4:
        return "https://images.unsplash.com/photo-1611605698335-8b1569810432?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600";
      case 5:
        return "https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600";
      default:
        return "https://images.unsplash.com/photo-1611162616475-46b635cb6868?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600";
    }
  };

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {isLoading && (
          <div className="space-y-6">
            <Skeleton className="w-2/3 h-10" />
            <Skeleton className="w-full h-80" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                <Skeleton className="w-full h-6" />
                <Skeleton className="w-full h-24" />
                <Skeleton className="w-full h-40" />
              </div>
              <div className="space-y-4">
                <Skeleton className="w-full h-64" />
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Có lỗi xảy ra</h3>
            <p className="text-gray-500 mb-6">{error}</p>
            <Button onClick={() => navigate("/")}>Quay lại trang chủ</Button>
          </div>
        )}

        {service && (
          <>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
              <div>
                <a 
                  href="/" 
                  className="text-sm text-primary-600 hover:text-primary-700 mb-2 inline-block"
                >
                  ← Quay lại danh sách dịch vụ
                </a>
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">{service.name}</h1>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold text-primary-600">{service.price.toLocaleString()} ₫</span>
                <Button onClick={handleOrderClick} className="whitespace-nowrap">Đặt dịch vụ</Button>
              </div>
            </div>

            <div className="relative rounded-2xl overflow-hidden mb-12">
              <img 
                src={getServiceImage(service.id)} 
                alt={service.name}
                className="w-full h-auto object-cover max-h-96"
              />
              {service.id === 1 && (
                <div className="absolute top-4 right-4 bg-green-500 text-white py-1 px-3 rounded-full text-sm font-medium">
                  Phổ biến nhất
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main content */}
              <div className="lg:col-span-2">
                <div className="prose prose-lg max-w-none">
                  <h2>Mô tả dịch vụ</h2>
                  <p>{service.description}</p>
                  
                  <h3>Tại sao nên chọn dịch vụ này?</h3>
                  <p>Dịch vụ {service.name} của chúng tôi cung cấp giải pháp chuyên nghiệp giúp bạn nhanh chóng lấy lại quyền truy cập vào tài khoản Facebook. Với đội ngũ kỹ thuật giàu kinh nghiệm, chúng tôi cam kết mang đến dịch vụ nhanh chóng, an toàn và hiệu quả.</p>
                  
                  <h3>Quy trình làm việc</h3>
                  <ol>
                    <li><strong>Đặt dịch vụ:</strong> Bạn điền thông tin và chi tiết về vấn đề tài khoản Facebook.</li>
                    <li><strong>Xác nhận và thanh toán:</strong> Chúng tôi xác nhận đơn hàng và bạn tiến hành thanh toán.</li>
                    <li><strong>Xử lý kỹ thuật:</strong> Đội ngũ kỹ thuật tiến hành các biện pháp cần thiết để khôi phục tài khoản.</li>
                    <li><strong>Bàn giao:</strong> Tài khoản được khôi phục và bàn giao lại cho bạn.</li>
                    <li><strong>Hỗ trợ sau dịch vụ:</strong> Chúng tôi tiếp tục hỗ trợ trong vòng 30 ngày sau khi hoàn thành.</li>
                  </ol>
                </div>
              </div>

              {/* Sidebar */}
              <div>
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 sticky top-24">
                  <h3 className="text-xl font-semibold mb-6">Thông tin dịch vụ</h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <Clock className="h-5 w-5 text-primary-600 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Thời gian xử lý</h4>
                        <p className="text-gray-600">{service.processingTime}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <Check className="h-5 w-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Tỷ lệ thành công</h4>
                        <p className="text-gray-600">Trên 95% cho dịch vụ này</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <Check className="h-5 w-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Bảo hành</h4>
                        <p className="text-gray-600">30 ngày sau khi hoàn thành</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <Check className="h-5 w-5 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-gray-900">Hỗ trợ</h4>
                        <p className="text-gray-600">24/7 qua tin nhắn và email</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-8">
                    <Button onClick={handleOrderClick} className="w-full" size="lg">
                      Đặt dịch vụ ngay
                    </Button>
                    <p className="text-sm text-gray-500 mt-3 text-center">
                      Đảm bảo hoàn tiền nếu không thành công
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </MainLayout>
  );
}