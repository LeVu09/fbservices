import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Pages
import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import ServiceDetails from "@/pages/service-details";
import FAQ from "@/pages/faq";
import Contact from "@/pages/contact";

// User pages
import UserDashboard from "@/pages/user/dashboard";
import UserOrders from "@/pages/user/orders";
import UserWallet from "@/pages/user/wallet";
import CreateOrder from "@/pages/user/create-order";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminUsers from "@/pages/admin/users";
import AdminOrders from "@/pages/admin/orders";
import AdminServices from "@/pages/admin/services";

// Authentication protection
import { useEffect, useState } from "react";
import { getCurrentUser, isAdmin } from "./lib/auth";
import { User } from "@shared/schema";

function AuthProtectedRoute({ component: Component, adminOnly = false, ...rest }: any) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [, navigate] = useLocation();

  useEffect(() => {
    async function checkAuth() {
      try {
        const userData = await getCurrentUser();
        setUser(userData);
        
        if (!userData) {
          navigate("/login");
          return;
        }
        
        if (adminOnly && !isAdmin(userData)) {
          navigate("/");
          return;
        }
      } catch (error) {
        console.error("Authentication check failed:", error);
        navigate("/login");
      } finally {
        setLoading(false);
      }
    }
    
    checkAuth();
  }, [navigate, adminOnly]);

  if (loading) {
    return <div className="flex h-screen items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
    </div>;
  }

  return <Component {...rest} />;
}

import { useLocation } from "wouter";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/service/:id" component={ServiceDetails} />
      <Route path="/faq" component={FAQ} />
      <Route path="/contact" component={Contact} />
      
      {/* User routes */}
      <Route path="/user/dashboard">
        <AuthProtectedRoute component={UserDashboard} />
      </Route>
      <Route path="/user/orders">
        <AuthProtectedRoute component={UserOrders} />
      </Route>
      <Route path="/user/wallet">
        <AuthProtectedRoute component={UserWallet} />
      </Route>
      <Route path="/user/create-order">
        <AuthProtectedRoute component={CreateOrder} />
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin/dashboard">
        <AuthProtectedRoute component={AdminDashboard} adminOnly={true} />
      </Route>
      <Route path="/admin/users">
        <AuthProtectedRoute component={AdminUsers} adminOnly={true} />
      </Route>
      <Route path="/admin/orders">
        <AuthProtectedRoute component={AdminOrders} adminOnly={true} />
      </Route>
      <Route path="/admin/services">
        <AuthProtectedRoute component={AdminServices} adminOnly={true} />
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
