import { apiRequest } from "./queryClient";
import { Login, Register, User } from "@shared/schema";

// Function to login a user
export async function login(credentials: Login): Promise<User> {
  const res = await apiRequest("POST", "/api/auth/login", credentials);
  return res.json();
}

// Function to register a new user
export async function register(userData: Register): Promise<User> {
  const res = await apiRequest("POST", "/api/auth/register", userData);
  return res.json();
}

// Function to logout the current user
export async function logout(): Promise<void> {
  await apiRequest("POST", "/api/auth/logout");
}

// Function to get the current user
export async function getCurrentUser(): Promise<User | null> {
  try {
    const res = await apiRequest("GET", "/api/auth/me");
    return await res.json();
  } catch (error) {
    console.error("Failed to get current user:", error);
    return null;
  }
}

// Helper function to check if the user is admin
export function isAdmin(user: User | null): boolean {
  return !!user?.isAdmin;
}
